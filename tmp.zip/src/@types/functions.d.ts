interface FunctionsLoginPayload {
  signature: string;
  code?: string;
}
