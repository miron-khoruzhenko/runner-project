interface Banner {
  redirect?: string;

  image: string;
}